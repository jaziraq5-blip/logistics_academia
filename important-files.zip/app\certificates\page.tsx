import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function CertificatesPage() {
  const certificates = [
    {
      icon: <span className="text-4xl">🏆</span>,
      title: "شهادة الأيزو 9001:2015",
      description: "شهادة إدارة الجودة الدولية",
      details: "معتمدة من قبل الهيئة الدولية للمعايير لضمان أعلى مستويات الجودة في خدماتنا",
    },
    {
      icon: <span className="text-4xl">🛡️</span>,
      title: "شهادة الأمان والسلامة",
      description: "معايير السلامة المهنية",
      details: "شهادة معتمدة تؤكد التزامنا بأعلى معايير الأمان في جميع عملياتنا",
    },
    {
      icon: <span className="text-4xl">✅</span>,
      title: "ترخيص النقل الدولي",
      description: "ترخيص رسمي للنقل الدولي",
      details: "مرخص من قبل السلطات المختصة لتقديم خدمات النقل والشحن الدولي",
    },
    {
      icon: <span className="text-4xl">⭐</span>,
      title: "شهادة التميز في الخدمة",
      description: "جائزة التميز في خدمة العملاء",
      details: "حاصلون على جائزة التميز في خدمة العملاء لثلاث سنوات متتالية",
    },
  ]

  const accreditations = [
    "عضوية الاتحاد الدولي للنقل البحري (IMO)",
    "عضوية جمعية النقل الجوي الدولي (IATA)",
    "اعتماد من غرفة التجارة الدولية",
    "شهادة من منظمة الجمارك العالمية",
    "عضوية اتحاد شركات الشحن العربية",
    "اعتماد من هيئة الموانئ الدولية",
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 to-sky-50 py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-6 animate-in fade-in slide-in-from-bottom duration-1000">
            الشهادات والاعتمادات
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto animate-in fade-in slide-in-from-bottom delay-300 duration-1000">
            نفتخر بحصولنا على أرفع الشهادات والاعتمادات الدولية التي تؤكد التزامنا بأعلى معايير الجودة والمهنية
          </p>
        </div>
      </section>

      {/* Certificates Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 animate-in fade-in slide-in-from-bottom duration-800">
            شهاداتنا المعتمدة
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {certificates.map((cert, index) => (
              <Card
                key={index}
                className="hover:shadow-xl hover:-translate-y-2 transition-all duration-500 group animate-in fade-in slide-in-from-bottom"
                style={{ animationDelay: `${(index + 1) * 150}ms` }}
              >
                <CardHeader className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className="group-hover:scale-110 transition-transform duration-300">{cert.icon}</div>
                  </div>
                  <CardTitle className="text-xl mb-2 group-hover:text-primary transition-colors duration-300">
                    {cert.title}
                  </CardTitle>
                  <CardDescription className="text-base font-medium text-primary">{cert.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-center">{cert.details}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Accreditations Section */}
      <section className="bg-gray-50 py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 animate-in fade-in slide-in-from-bottom duration-800">
            العضويات والاعتمادات
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {accreditations.map((accreditation, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-lg shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-500 animate-in fade-in slide-in-from-bottom group"
                style={{ animationDelay: `${(index + 1) * 100}ms` }}
              >
                <div className="flex items-center space-x-3 rtl:space-x-reverse">
                  <div className="w-6 h-6 text-green-500 flex-shrink-0 group-hover:scale-110 transition-transform duration-300">
                    ✅
                  </div>
                  <span className="font-medium text-foreground group-hover:text-primary transition-colors duration-300">
                    {accreditation}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quality Commitment Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-8 animate-in fade-in slide-in-from-bottom duration-800">
              التزامنا بالجودة
            </h2>
            <p className="text-lg text-muted-foreground mb-8 animate-in fade-in slide-in-from-bottom delay-300 duration-800">
              نؤمن بأن الجودة ليست مجرد هدف نسعى إليه، بل هي أسلوب حياة نعيشه في كل تفصيل من تفاصيل عملنا. شهاداتنا
              واعتماداتنا هي شاهد على التزامنا المستمر بتقديم أفضل الخدمات لعملائنا الكرام.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
              <div className="text-center animate-in fade-in slide-in-from-bottom delay-500 duration-700 hover:-translate-y-2 transition-transform duration-300 group">
                <div className="text-4xl font-bold text-primary mb-2 group-hover:scale-110 transition-transform duration-300">
                  15+
                </div>
                <p className="text-muted-foreground">سنة من الخبرة</p>
              </div>
              <div className="text-center animate-in fade-in slide-in-from-bottom delay-600 duration-700 hover:-translate-y-2 transition-transform duration-300 group">
                <div className="text-4xl font-bold text-primary mb-2 group-hover:scale-110 transition-transform duration-300">
                  500+
                </div>
                <p className="text-muted-foreground">عميل راضٍ</p>
              </div>
              <div className="text-center animate-in fade-in slide-in-from-bottom delay-700 duration-700 hover:-translate-y-2 transition-transform duration-300 group">
                <div className="text-4xl font-bold text-primary mb-2 group-hover:scale-110 transition-transform duration-300">
                  99%
                </div>
                <p className="text-muted-foreground">معدل رضا العملاء</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary text-primary-foreground py-16 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-32 h-32 bg-white rounded-full animate-pulse"></div>
          <div className="absolute bottom-10 right-10 w-24 h-24 bg-sky-300 rounded-full animate-bounce delay-1000"></div>
          <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-blue-300 rounded-full animate-ping delay-500"></div>
        </div>

        <div className="container mx-auto px-4 text-center relative z-10">
          <h2 className="text-3xl font-bold mb-6 animate-in fade-in slide-in-from-bottom duration-800">
            ثق في خبرتنا المعتمدة
          </h2>
          <p className="text-xl mb-8 opacity-90 animate-in fade-in slide-in-from-bottom delay-300 duration-800">
            اختر الشريك الذي يضمن لك أعلى معايير الجودة والمهنية
          </p>
          <a
            href="/contact"
            className="inline-block bg-white text-primary px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 hover:scale-105 transition-all duration-300 animate-in fade-in slide-in-from-bottom delay-600"
          >
            تواصل معنا
          </a>
        </div>
      </section>
    </div>
  )
}
