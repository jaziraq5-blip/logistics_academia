"use client"

import Link from "next/link"
import { useLanguage } from "@/contexts/language-context"

export default function Footer() {
  const { t } = useLanguage()

  return (
    <footer className="bg-blue-800 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                <span className="text-blue-800 font-bold">L</span>
              </div>
              <span className="font-bold text-lg">{t("footer.companyName")}</span>
            </div>
            <p className="text-blue-100 text-sm leading-relaxed">{t("footer.description")}</p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">{t("footer.quickLinks")}</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-blue-100 hover:text-white transition-colors">
                  {t("nav.about")}
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-blue-100 hover:text-white transition-colors">
                  {t("nav.services")}
                </Link>
              </li>
              <li>
                <Link href="/import-export" className="text-blue-100 hover:text-white transition-colors">
                  {t("nav.importExport")}
                </Link>
              </li>
              <li>
                <Link href="/certificates" className="text-blue-100 hover:text-white transition-colors">
                  {t("nav.certificates")}
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">{t("footer.services")}</h3>
            <ul className="space-y-2">
              <li className="text-blue-100">{t("home.seaFreight")}</li>
              <li className="text-blue-100">{t("home.airFreight")}</li>
              <li className="text-blue-100">{t("home.landTransport")}</li>
              <li className="text-blue-100">{t("home.customsClearance")}</li>
              <li className="text-blue-100">{t("services.warehouseTitle")}</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg">{t("footer.contact")}</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <span className="text-blue-300">📞</span>
                <span className="text-blue-100">+966 11 123 4567</span>
              </div>
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <span className="text-blue-300">✉️</span>
                <span className="text-blue-100">info@advancedlogistics.com</span>
              </div>
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <span className="text-blue-300">📍</span>
                <span className="text-blue-100">King Fahd Road, Al Olaya, Riyadh 12211, Saudi Arabia</span>
              </div>
            </div>

            {/* Social Media */}
            <div className="flex space-x-4 rtl:space-x-reverse pt-4">
              <span className="text-blue-100 text-sm opacity-75">
                Follow us on social media
              </span>
            </div>
          </div>
        </div>

        <div className="border-t border-blue-700 mt-8 pt-8 text-center">
          <p className="text-blue-200 text-sm">
            © 2025 {t("footer.companyName")}. {t("footer.rights")}.
          </p>
        </div>
      </div>
    </footer>
  )
}
