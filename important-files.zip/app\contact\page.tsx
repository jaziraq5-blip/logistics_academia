"use client"

import Header from "@/components/header"
import Footer from "@/components/footer"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useLanguage } from "@/contexts/language-context"
import { Phone, Mail, MapPin, Clock, Facebook, Twitter, Linkedin, Instagram } from "lucide-react"

export default function ContactPage() {
  const { t } = useLanguage()
  return (
    <div className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary to-secondary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <Badge variant="secondary" className="mb-4 animate-in fade-in delay-300 duration-700">
            {t("contact.title")}
          </Badge>
          <h1 className="text-4xl lg:text-6xl font-bold mb-6 animate-in fade-in slide-in-from-bottom delay-500 duration-1000">
            {t("contact.heroTitle")}
          </h1>
          <p className="text-xl max-w-3xl mx-auto text-primary-foreground/90 animate-in fade-in slide-in-from-bottom delay-700 duration-1000">
            {t("contact.heroSubtitle")}
          </p>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="animate-in fade-in slide-in-from-left duration-1000">
              <Badge variant="outline" className="mb-4 animate-in fade-in delay-200 duration-600">
                {t("contact.contactFormTitle")}
              </Badge>
              <h2 className="text-3xl font-bold mb-6 animate-in fade-in slide-in-from-left delay-300 duration-800">
                {t("contact.sendMessageTitle")}
              </h2>
              <Card className="hover:shadow-xl transition-all duration-500 animate-in fade-in slide-in-from-left delay-500">
                <CardContent className="p-6">
                  <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2 animate-in fade-in slide-in-from-left delay-700 duration-500">
                        <Label htmlFor="firstName">{t("contact.firstName")}</Label>
                        <Input
                          id="firstName"
                          placeholder={t("contact.enterFirstName")}
                          className="hover:border-primary/50 transition-colors duration-300"
                        />
                      </div>
                      <div className="space-y-2 animate-in fade-in slide-in-from-left delay-800 duration-500">
                        <Label htmlFor="lastName">{t("contact.lastName")}</Label>
                        <Input
                          id="lastName"
                          placeholder={t("contact.enterLastName")}
                          className="hover:border-primary/50 transition-colors duration-300"
                        />
                      </div>
                    </div>

                    <div className="space-y-2 animate-in fade-in slide-in-from-left delay-900 duration-500">
                      <Label htmlFor="email">{t("contact.email")}</Label>
                      <Input id="email" type="email" placeholder={t("contact.enterEmail")} />
                    </div>

                    <div className="space-y-2 animate-in fade-in slide-in-from-left delay-1000 duration-500">
                      <Label htmlFor="phone">{t("contact.phone")}</Label>
                      <Input id="phone" type="tel" placeholder={t("contact.enterPhone")} />
                    </div>

                    <div className="space-y-2 animate-in fade-in slide-in-from-left delay-1100 duration-500">
                      <Label htmlFor="company">{t("contact.company")}</Label>
                      <Input id="company" placeholder={t("contact.enterCompany")} />
                    </div>

                    <div className="space-y-2 animate-in fade-in slide-in-from-left delay-1200 duration-500">
                      <Label htmlFor="service">{t("contact.serviceType")}</Label>
                      <select className="w-full p-3 border border-input rounded-md bg-background">
                        <option value="">{t("contact.chooseService")}</option>
                        <option value="sea-freight">{t("contact.seaFreight")}</option>
                        <option value="air-freight">{t("contact.airFreight")}</option>
                        <option value="land-transport">{t("contact.landTransport")}</option>
                        <option value="customs-clearance">{t("contact.customsClearance")}</option>
                        <option value="import-export">{t("contact.importExport")}</option>
                        <option value="warehousing">{t("contact.warehousing")}</option>
                        <option value="other">{t("contact.other")}</option>
                      </select>
                    </div>

                    <div className="space-y-2 animate-in fade-in slide-in-from-left delay-1300 duration-500">
                      <Label htmlFor="message">{t("contact.message")}</Label>
                      <Textarea id="message" placeholder={t("contact.tellUsNeeds")} rows={5} />
                    </div>

                    <Button
                      type="submit"
                      className="w-full hover:scale-105 transition-all duration-300 animate-in fade-in slide-in-from-left delay-1500"
                      size="lg"
                      aria-label={`${t("contact.sendMessage")} - Submit your inquiry to our logistics team`}
                    >
                      {t("contact.sendMessage")}
                      <span className="mr-2">📧</span>
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Contact Information */}
            <div className="animate-in fade-in slide-in-from-right duration-1000">
              <Badge variant="outline" className="mb-4 animate-in fade-in delay-200 duration-600">
                {t("contact.contactInfoTitle")}
              </Badge>
              <h2 className="text-3xl font-bold mb-6 animate-in fade-in slide-in-from-right delay-300 duration-800">
                {t("contact.contactDirectlyTitle")}
              </h2>

              <div className="space-y-6">
                <Card className="hover:shadow-xl hover:-translate-y-1 transition-all duration-500 animate-in fade-in slide-in-from-right delay-500 group">
                  <CardHeader>
                    <div className="flex items-center space-x-3 rtl:space-x-reverse">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300">
                        <Phone className="w-5 h-5 text-primary" />
                      </div>
                      <CardTitle className="group-hover:text-primary transition-colors duration-300">{t("contact.phone")}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-2">{t("contact.callDirectly")}</p>
                    <p className="font-semibold hover:text-primary transition-colors duration-300">+966 11 123 4567</p>
                    <p className="font-semibold hover:text-primary transition-colors duration-300">+966 11 123 4568</p>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-xl hover:-translate-y-1 transition-all duration-500 animate-in fade-in slide-in-from-right delay-600 group">
                  <CardHeader>
                    <div className="flex items-center space-x-3 rtl:space-x-reverse">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300">
                        <Mail className="w-5 h-5 text-primary" />
                      </div>
                      <CardTitle className="group-hover:text-primary transition-colors duration-300">
                        {t("contact.email")}
                      </CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-2">{t("contact.emailUs")}</p>
                    <p className="font-semibold hover:text-primary transition-colors duration-300">
                      info@advancedlogistics.com
                    </p>
                    <p className="font-semibold hover:text-primary transition-colors duration-300">
                      sales@advancedlogistics.com
                    </p>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-xl hover:-translate-y-1 transition-all duration-500 animate-in fade-in slide-in-from-right delay-700 group">
                  <CardHeader>
                    <div className="flex items-center space-x-3 rtl:space-x-reverse">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300">
                        <MapPin className="w-5 h-5 text-primary" />
                      </div>
                      <CardTitle className="group-hover:text-primary transition-colors duration-300">{t("contact.address")}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-2">{t("contact.mainOffice")}</p>
                    <p className="font-semibold">
                      شارع الملك فهد، حي العليا
                      <br />
                      الرياض 12211
                      <br />
                      المملكة العربية السعودية
                    </p>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-xl hover:-translate-y-1 transition-all duration-500 animate-in fade-in slide-in-from-right delay-800 group">
                  <CardHeader>
                    <div className="flex items-center space-x-3 rtl:space-x-reverse">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300">
                        <Clock className="w-5 h-5 text-primary" />
                      </div>
                      <CardTitle className="group-hover:text-primary transition-colors duration-300">
                        {t("contact.workingHours")}
                      </CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between hover:translate-x-1 transition-transform duration-200">
                        <span>{t("contact.sundayThursday")}</span>
                        <span className="font-semibold">8:00 ص - 6:00 م</span>
                      </div>
                      <div className="flex justify-between hover:translate-x-1 transition-transform duration-200">
                        <span>{t("contact.friday")}</span>
                        <span className="font-semibold">مغلق</span>
                      </div>
                      <div className="flex justify-between hover:translate-x-1 transition-transform duration-200">
                        <span>{t("contact.saturday")}</span>
                        <span className="font-semibold">9:00 ص - 2:00 م</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Social Media */}
                <Card className="hover:shadow-xl hover:-translate-y-1 transition-all duration-500 animate-in fade-in slide-in-from-right delay-900 group">
                  <CardHeader>
                    <CardTitle className="group-hover:text-primary transition-colors duration-300">
                      {t("contact.socialMedia")}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex space-x-4 rtl:space-x-reverse">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center opacity-50">
                        <Facebook className="w-5 h-5" />
                      </div>
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center opacity-50">
                        <Twitter className="w-5 h-5" />
                      </div>
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center opacity-50">
                        <Linkedin className="w-5 h-5" />
                      </div>
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center opacity-50">
                        <Instagram className="w-5 h-5" />
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      Social media links coming soon
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-20 bg-muted">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 animate-in fade-in slide-in-from-bottom duration-800">
            <Badge variant="outline" className="mb-4 animate-in fade-in delay-200 duration-600">
              {t("contact.locationTitle")}
            </Badge>
            <h2 className="text-3xl font-bold mb-4 animate-in fade-in slide-in-from-bottom delay-300 duration-800">
              {t("contact.visitUsTitle")}
            </h2>
            <p className="text-muted-foreground animate-in fade-in slide-in-from-bottom delay-500 duration-800">
              {t("contact.locationSubtitle")}
            </p>
          </div>

          <div className="bg-background rounded-lg p-4 shadow-lg hover:shadow-xl transition-all duration-500 animate-in fade-in slide-in-from-bottom delay-700">
            <div className="aspect-video bg-muted rounded-lg flex items-center justify-center group hover:bg-muted/80 transition-colors duration-300">
              <div className="text-center">
                <div className="w-12 h-12 text-primary mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <MapPin className="w-12 h-12" />
                </div>
                <p className="text-muted-foreground">{t("contact.interactiveMap")}</p>
                <p className="text-sm text-muted-foreground mt-2">شارع الملك فهد، حي العليا، الرياض</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
